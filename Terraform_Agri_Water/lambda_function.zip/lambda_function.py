import json
import logging

import boto3

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Initialize IoT Data client
iot_client = boto3.client('iot-data')

def lambda_handler(event, context):
    logger.info("Event: %s", json.dumps(event))

    # Initialize counters for each sprinkler
    counters = {
        'Sprinkler_01': {'on': 0, 'off': 0, 'total': 0},
        'Sprinkler_02': {'on': 0, 'off': 0, 'total': 0},
        'Sprinkler_03': {'on': 0, 'off': 0, 'total': 0},
        'Sprinkler_04': {'on': 0, 'off': 0, 'total': 0},
    }

    try:
        # Process each record in the event
        for record in event.get('Records', []):
            try:
                data = json.loads(record.get('Data', '{}'))
                partition_key = record.get('PartitionKey', '')
                temperature = data.get('Temperature')
                moisture = data.get('Moisture')

                if partition_key not in counters:
                    logger.warning("Unknown partition key: %s", partition_key)
                    continue

                if temperature is None or moisture is None:
                    logger.warning("Missing temperature or moisture data in record: %s", record)
                    continue

                # Check conditions for 'ON' and 'OFF' states
                if temperature > 35 and moisture < 40:
                    counters[partition_key]['on'] += 1
                elif temperature < 20 and moisture > 60:
                    counters[partition_key]['off'] += 1
                counters[partition_key]['total'] += 1

                logger.info("Processed record for %s: %s", partition_key, json.dumps(data))
            except json.JSONDecodeError:
                logger.error("Error decoding JSON data in record: %s", record)
            except Exception as e:
                logger.error("Unexpected error processing record: %s, error: %s", record, str(e))

        # Determine the final status for each sprinkler
        statuses = {}
        for sprinkler, counts in counters.items():
            if counts['total'] == 0:
                statuses[sprinkler] = "NO_DATA"
                continue  # Skip if no data for this sprinkler

            # Determine status based on more than or equal to 50% of 'on' or 'off'
            if counts['on'] / counts['total'] >= 0.5:
                status = "ON"
            elif counts['off'] / counts['total'] >= 0.5:
                status = "OFF"
            else:
                status = "OFF"  # Default to 'OFF' if no clear majority

            statuses[sprinkler] = status
            message = json.dumps({f"{sprinkler} Status": status})

            try:
                # Publish the status to the IoT topic
                response = iot_client.publish(
                    topic='iot/ws',
                    qos=1,
                    payload=message
                )
                logger.info("Published status for %s: %s", sprinkler, message)
            except Exception as e:
                logger.error("Error publishing status for %s: %s", sprinkler, str(e))

        logger.info("Final statuses: %s", json.dumps(statuses))

    except Exception as e:
        logger.error("Unexpected error in lambda_handler: %s", str(e))
        return {
            'statusCode': 500,
            'body': json.dumps('Error processing statuses')
        }

    return {
        'statusCode': 200,
        'body': json.dumps('Statuses processed successfully')
    }
